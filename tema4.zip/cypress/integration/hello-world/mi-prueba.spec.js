describe('GIVEN: add task', () => {
  const url = 'https://www.timeanddate.com';
  const formButton =
    '.box-bottom > .clip-block > .bn-header__searchbox > .picker-city__button > .i-font';
  const formInput = '.box-bottom > .clip-block > .bn-header__searchbox > .picker-city__input';
  const inputDescription = 'Madrid';

  context('WHEN: type and click', () => {
    before(() => {
      cy.visit(url); // USUARIO VISITA LA PÁGINA
      cy.get(formInput).type(inputDescription); // INPUT PARA OBTENER ELEMENTO Y TECLEAR
      cy.get(formButton).click(); // AGREGAR TAREA Y HACER CLICK
    });
    const ele = '.picker-city__input';
    it(`THEN: should have ${inputDescription} on input`, () => {
      cy.get(ele).should('include', inputDescription);
    });
  });
});
